<textarea
    name="fields<?php echo $field_name;?>[<?php echo $field['key'];?>]"
    class="widefat rad4">
    <?php echo esc_attr( $current_field );?>
</textarea>
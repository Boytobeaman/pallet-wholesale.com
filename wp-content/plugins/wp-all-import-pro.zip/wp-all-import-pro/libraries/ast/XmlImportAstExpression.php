<?php
/**
 * @author Olexandr Zanichkovsky <olexandr.zanichkovsky@zophiatech.com>
 * @package AST
 */

/**
 * Represents expression
 *
 * @abstract
 */
abstract class XmlImportAstExpression
{
  
}

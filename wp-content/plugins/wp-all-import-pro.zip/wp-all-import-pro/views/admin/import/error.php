<?php foreach ($errors as $msg): ?>
	<div class="error inline"><p><?php echo $msg ?></p></div>
<?php endforeach ?>